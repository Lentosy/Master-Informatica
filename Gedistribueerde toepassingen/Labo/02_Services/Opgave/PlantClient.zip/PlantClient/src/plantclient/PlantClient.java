/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantclient;

import java.util.List;
import tiwi.plant.Plant;

/**
 *
 * @author vongenae
 */
public class PlantClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        toonPlanten("rood");
        
        Plant plant = new Plant();
        plant.setKleur("rood");
        plant.setNaam("roos");
        plant.setPrijs(4);
        
        voegPlantToe(plant);
        
        toonPlanten("rood");
    }

    private static void toonPlanten(String kleur) {
        List<Plant> planten = getPlanten(kleur);
        for (Plant plant : planten) {
            System.out.println(plant.getNaam());
        }
    }

    private static java.util.List<tiwi.plant.Plant> getPlanten(java.lang.String kleur) {
        tiwi.plant.PlantenSOAP_Service service = new tiwi.plant.PlantenSOAP_Service();
        tiwi.plant.PlantenSOAP port = service.getPlantenSOAPPort();
        return port.getPlanten(kleur);
    }

    private static String voegPlantToe(tiwi.plant.Plant plant) {
        tiwi.plant.PlantenSOAP_Service service = new tiwi.plant.PlantenSOAP_Service();
        tiwi.plant.PlantenSOAP port = service.getPlantenSOAPPort();
        return port.voegPlantToe(plant);
    }
    
}
