package tictactoeclient;

import javax.swing.JFrame;

public class TicTacToeClient {

    /**
     * Runs the client as an application.
     *
     * @param args
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        TicTacToeFrame frame = new TicTacToeFrame();
        new Thread(() -> {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 300);
            frame.setVisible(true);
            frame.setResizable(false);
        }).start();

    }
}
