int x = 5;
int u = 10000;
double y = 4.794;
double z = 4.5;
double w = 4.;
print("stringliteral");
