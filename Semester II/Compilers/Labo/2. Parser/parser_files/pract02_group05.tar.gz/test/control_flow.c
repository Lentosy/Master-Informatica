if(x == 5){

} else {
    print(funct(parameter));
}


if(y == "een string met spaties en een underscore _"){
    int top = 100;
    for(int i = 1; i < top; i = i + 1) {
        print(i);
    }
}


while(z - 4 < 9 + 7) {
    func(func(func(z)));
}

int functie(){
    return x;
}

int functie2(){
    return;
}
