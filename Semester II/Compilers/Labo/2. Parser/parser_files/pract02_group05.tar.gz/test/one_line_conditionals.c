if(something)
  foo();
else
  bar();
