simple_function();
sin(x);
foo(x, bar(y, zoo()), z);
foo(bar(y, zoo(inner(function(many(parameter)))),some_other_function()));
