void hello_world() {
	print("Hello, World!");
}

hello_world();
