int answer = 42;
echo(answer);
