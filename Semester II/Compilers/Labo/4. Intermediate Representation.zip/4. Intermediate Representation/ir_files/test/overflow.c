int foo[10]; int n = 10;
foo[n] = 0;
