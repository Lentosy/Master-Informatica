int n = 10;
int sum = 0;
for (int i = 0; i < n; i = i+1) {
    sum = sum + i;
}
